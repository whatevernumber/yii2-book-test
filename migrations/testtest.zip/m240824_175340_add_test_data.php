<?php

use yii\db\Migration;

/**
 * Class m240824_175340_add_test_data
 */
class m240824_175340_add_test_data extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->insert('users', [
            'email' => 'test@test.test',
            'name' => 'Тестовый юзер',
            'password' => Yii::$app->getSecurity()->generatePasswordHash('test'),
        ]);

        $this->batchInsert('books',
            ['id', 'title', 'isbn', 'description', 'published_year', 'cover'],
            [
                [
                    1,
                    'Голубая точка',
                    '9785916717884',
                    'Выдающийся популяризатор науки, прекрасный рассказчик, страстный пропагандист космоса, провидец, Карл Саган считает, что стремление странствовать и расширять границы знаний, свойственно природе человека и связано с нашим выживанием как вида.
                                        В его искренней, захватывающей книге философские размышления переплетаются с восторженными описаниями триумфальных исследований планет и спутников как с участием человека, посещавшего Луну, так и роботизированных миссий.
                                        Знакомя нас с нашими соседями по космосу, Саган не просто просвещает и восхищает читателя, он и помогает понять, как защитить Землю.',
                    '2024',
                    'weread-sagan_1.jpg',
                ],
            ]);

        $this->batchInsert('authors',
            ['id', 'name'],
            [
                [
                    1,
                    'Карл Саган'
                ],
                [
                    2,
                    'Робер Сапольски'
                ],
                [
                    3,
                    'Лю Цысинь'
                ],
                [
                    4,
                    'Айзек Азимов'
                ],
                [
                    5,
                    'Филипп Дик'
                ]
            ]);

        $this->batchInsert('author_book',
            ['author_id', 'book_id'],
            [
                [1, 1],
            ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->truncateTable('users');
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m240824_175340_add_test_data cannot be reverted.\n";

        return false;
    }
    */
}
